/* tslint:disable */
/* eslint-disable */
export function init(): void;
export function upscale_image(data: Uint8Array, width: number, height: number, scale_factor: number): Uint8Array;
